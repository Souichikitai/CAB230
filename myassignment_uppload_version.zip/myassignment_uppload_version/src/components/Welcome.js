import React, { useState } from 'react';
import {
    Carousel,
    CarouselItem,
    CarouselControl,
    CarouselIndicators,
    CarouselCaption,
    Jumbotron, Button
  } from 'reactstrap';
  import {
    Link
  } from 'react-router-dom';


  const items = [
    {
      src: 'https://www.pakutaso.com/shared/img/thumb/CC176164632_TP_V.jpg',
      altText: 'Welcome to stocks library',
      caption: 'detail'
    },
    {
      src: 'https://images.unsplash.com/photo-1466903001289-713a94ef08df?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
      altText: 'About this website',
      caption: ''
    },
    {
      src: 'https://images.unsplash.com/photo-1533367972136-b8b844e9cfb5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
      altText: 'New ?',
      caption: 'Register now by click'
    }
  ];


  
  export const Welcome = (props) => {
    const [activeIndex, setActiveIndex] = useState(0);
    const [animating, setAnimating] = useState(false);
  
    const next = () => {
      if (animating) return;
      const nextIndex = activeIndex === items.length - 1 ? 0 : activeIndex + 1;
      setActiveIndex(nextIndex);
    }
  
    const previous = () => {
      if (animating) return;
      const nextIndex = activeIndex === 0 ? items.length - 1 : activeIndex - 1;
      setActiveIndex(nextIndex);
    }
  
    const goToIndex = (newIndex) => {
      if (animating) return;
      setActiveIndex(newIndex);
    }

    const onclickreaction = () => {
        console.log("Hi");
    }

    
  
    const slides = items.map((item) => {
      return (
        <CarouselItem
          className = "custom-tag"
          onExiting={() => setAnimating(true)}
          onExited={() => setAnimating(false)}
          key={item.src}
          
        >
          <img className="custom-img" src={item.src} alt={item.altText} onClick={onclickreaction}/>
          <CarouselCaption captionText={item.caption} captionHeader={item.altText} />
        </CarouselItem>
      );
    });

  
    return (
    <div>
        <style>
        {
          `.custom-img{
              width: 100%;
              height:550px;
          }`
        }
      </style>

      <Carousel
        activeIndex={activeIndex}
        next={next}
        previous={previous}
      >
        <CarouselIndicators items={items} activeIndex={activeIndex} onClickHandler={goToIndex} />
        {slides}
        <CarouselControl className="text-danger" direction="prev" directionText="Previous" onClickHandler={previous} />
        <CarouselControl direction="next" directionText="Next" onClickHandler={next} />
      </Carousel>
      
        <Jumbotron color="info">
        <h1 className="display-3" >Hello, world!</h1>
        <p className="text-info">Stocks library is a website where you can search a variety of stocks in any industry area.</p>
        <hr className="my-2" />
        <p className="text-info"> There are also some functions you can use to search stocks by filtering dates, and areas with such as charting and a data table.</p>
        <p className="lead">
          <Button color="primary"><Link to={'/register'} style={{color: 'white'}}>Get started</Link></Button>
        </p>
      </Jumbotron>
    </div>
    );
  }
  
  export default Welcome;