import React, { Component } from 'react';
import axios from 'axios';
import '../App.css';
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { selectFilter, textFilter } from 'react-bootstrap-table2-filter';
import paginationFactory from 'react-bootstrap-table2-paginator';
import {
    Link
  } from 'react-router-dom'
  import { Jumbotron} from 'reactstrap';
const localhost = 'http://131.181.190.87:3000';

export default class Stocklists extends Component{

    constructor(props){
        super(props)

        this.state = {
            stock_data: [],
        }
        
    }

    getstockdata(){
        axios.get(`${localhost}/stocks/symbols`)
        .then(res => {

            this.setState({stock_data: res.data})
        })
        .catch(error => {
            console.log(error)
        });
    }

    componentDidMount(){
        this.getstockdata();
    }
    

    render(){
        
        const columns = [

            {
                text: "Name",
                dataField: "name",
                filter: textFilter()
            },
            {
                dataField: "industry",
                text: "Industry",
                filter: textFilter()
            },
            {
                text: "Symbol",
                dataField: "symbol",
                filter: textFilter()
            }
        ]

        let stockdata = this.state.stock_data;
        
        return(

            <div className="App">
                
                <div className="stock-title">
                <Jumbotron>
                        <h1 className="display-3">All stock lists</h1>
                        <hr className="my-2" />
                        <p>Search by name, industry, symbol</p>
                        <p>Industry lists available<Link to={'/industrylists'}> here</Link></p>
                </Jumbotron>

                <BootstrapTable keyField='name' data={stockdata} columns={ columns } pagination={ paginationFactory()} filter={ filterFactory()}/>
                
                </div>


            </div>

            

        )
    }
}
