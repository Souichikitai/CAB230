import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import axios from 'axios';
import { Jumbotron, Alert } from 'reactstrap';
import "react-datepicker/dist/react-datepicker.css";
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import {Line} from 'react-chartjs-2';
import Chart from 'chart.js';


const localhost = 'http://131.181.190.87:3000';

export default class Top extends Component{

    constructor(props){
        super(props)

        this.state = {
            stock: [],
            startDate:"",
            endDate: "",
            symbol:"",
            chart_data:[],
            iserror: false,
            visible: false,
            tableshow: false,
            errormessage: ""
        };
        this.getstockdate = this.getstockdate.bind(this);
    }

    
    getstockdate(e){
        let close_data = [];
        let date_data = [];
        e.preventDefault();
        const token = localStorage.getItem("jwt");        
        const headers = {
            Authorization: `Bearer ${token}`
        };

        const input = this.state.symbol;

        const parse_from = this.state.startDate;
        const parse_to = this.state.endDate;

        console.log(parse_from);
        console.log(parse_to);

        axios.get(`http://131.181.190.87:3000/stocks/authed/${input}?from=${parse_from}&to=${parse_to}`, {headers})
        .then(res => {
            console.log(res.data)
            for(const dataObj of res.data){
                close_data.push(dataObj.close)
                date_data.push(dataObj.timestamp)
            }
            this.setState({stock: res.data})
            // console.log(res.data.close)
        })
        .catch(error => {
            
            this.setState({errormessage: error.message})
            console.log(this.state.errormessage);
            this.setState({iserror: true})
            this.setState({visible: true})
            console.log(this.state.iserror)
        });

        this.setState({chart_data: {
            labels: date_data,
            datasets:[
                {
                    label: "data",
                    data: close_data
                }
            ],
            options: {
                scales: {
                  xAxes: [ {

                    }
                  ],
                  yAxis: [{
                    display: true,
                    type: 'time',
                    time: {
                      parser: 'MM/DD/YYYY HH:mm',
                      tooltipFormat: 'll HH:mm',
                      unit: 'day',
                      unitStepSize: 1,
                      displayFormats: {
                        'day': 'MM/DD/YYYY'
                      }
                    }
                  }
                  ],
                }
              }
        }})
        this.setState({tableshow: true});
        console.log(close_data);
    }

    renderErrorMessage(){
        const onDismiss = () => this.setState({visible: false});
        if(this.state.iserror===true){
            if(this.state.errormessage === "Request failed with status code 400"){
                return (
                    <div>
                    <Alert color="secondary" isOpen={this.state.visible} toggle={onDismiss}>
                    Stock symbol incorrect format - must be 1-5 capital letters
                    </Alert>
                    </div>
                  );
            }
        }        
    }

    change(e){
        this.setState({
            symbol: e.target.value,
            tableshow: false
        })
        
        this.setState({chart_data: []})
        // window.location.reload(false);
    }

    reset(e){
        this.setState({chart_data: []})
        // e.preventDefault();
        // window.location.reload(false);
    }

    showtable(){
        let stockdata = this.state.stock;
        const columns = [
            {
                text: "Date",
                dataField: "timestamp",
                sort: true,
                formatter: (cell) => {
                    let dateObj = cell;

                    if (typeof cell !== 'object') {
                      dateObj = new Date(cell);
                    }
                    return `${('0' + dateObj.getUTCDate()).slice(-2)}/${('0' + (dateObj.getUTCMonth() + 1)).slice(-2)}/${dateObj.getUTCFullYear()}`;
                  },
            },
            {
                text: "Name",
                dataField: "name",
            },
            {
                text: "Industry",
                dataField: "industry"
            },
            {
                text: "Open",
                dataField: "open"
            },
            {
                text: "High",
                dataField: "high"
            },
            {
                text: "Low",
                dataField: "low"
            },
            {
                text: "Close",
                dataField: "close"
            },
            {
                text: "Volumes",
                dataField: "volumes"
            }
        ]
        if(this.state.tableshow === true){
            return(
                <div className="top_table">
                <BootstrapTable keyField='id' data={ stockdata } columns={ columns } pagination={ paginationFactory()}/>
                <Line data = {this.state.chart_data} options = {{
                    responsive: true
                }}/>
                </div>
            )
        }
    }


    render(){


        
        const min = new Date(2019, 10, 6);
        const max = new Date(2020, 2, 24);

        return(
            
            <div>
                {this.renderErrorMessage()} 
                <div className="top_date_picker">
                <Jumbotron>
                    <h1 className="display-3">Search stock lists by filtering date</h1>
                    <p className="lead">You can search all stock lists from 6 November 2019 to 24 March 2020</p>
                    <hr className="my-2" />
                    <p>Date columns can be sorten</p>
                </Jumbotron>
                <h5>Please put dates to filter</h5>
                <DatePicker
                    minDate={min}
                    maxDate={max}
                    selected={this.state.startDate}
                    onChange={date => this.setState({startDate: date})}                   
                    selectsStart
                    startDate={this.state.startDate}
                    endDate={this.state.endDate}
                    isClearable
                />
                <h6>to</h6>
                <DatePicker
                    minDate={min}
                    maxDate={max}
                    selected={this.state.endDate}
                    onChange={date => this.setState({endDate: date})}                    
                    selectsEnd
                    startDate={this.state.startDate}
                    endDate={this.state.endDate}
                    isClearable

                />
                
                <h5 className="top_date_picker">Please provide symbols</h5>
                <form className="stock-table1" onSubmit = {this.getstockdate}>
                    <input type="text" name="symbol" onChange = {e => this.change(e)}/>
                    <button className="input">Search</button>
                </form> 
                </div>
                {this.showtable()}

            </div>
        )
    }
}
