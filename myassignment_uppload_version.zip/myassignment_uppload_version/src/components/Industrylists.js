import React, {Component} from 'react';
import '../App.css';

class Industrylists extends Component{

    constructor(props){
        super(props)
        
    }

    render(){

        return(
            <div id="list2">
            <ol>
                <h1>Industrials Lists</h1>
                <li><p><em>Health Care</em></p></li>
                <li><p><em>Industrials</em></p></li>
                <li><p><em>Consumer Discretionary</em></p></li>
                <li><p><em>Information Technology</em></p></li>
                <li><p><em>Consumer Staples</em></p></li>
                <li><p><em>Utilities</em></p></li>
                <li><p><em>Real Estate</em></p></li>
                <li><p><em>Materials</em></p></li>
                <li><p><em>Energy</em></p></li>
                <li><p><em>Telecommunication Services</em></p></li>
            </ol>
            </div>
        )
    }

}

export default Industrylists;
