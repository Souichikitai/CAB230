import React, {Component} from 'react';
import { Button, Form, FormGroup, Label, Input, Col } from 'reactstrap';
import '../App.css';
// import {withRouter} from 'react-router-dom';
import axios from 'axios';

import {connect} from 'react-redux';
import {setLoginTrue} from '../actions/action'

const localhost = 'http://131.181.190.87:3000'

class Login extends Component{
    constructor(props){
        super(props);
        this.state = {
            content: "",
            email:"",
            password: "" ,
            errormessage:"",
            iserror: false,
            doncheck: this.iserror?"Error":"",
            
        }
        this.change = this.change.bind(this);
        this.submit = this.submit.bind(this);
    }

    change(e){
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    submit(e){

        e.preventDefault();
        axios.post(`${localhost}/user/login`, {
            email: this.state.email,
            password: this.state.password
        }).then(res => {
            localStorage.setItem('jwt', res.data.token);
            console.log(res.data.token)
            this.props.history.push('/top');
            this.props.signIn();
        }).catch(error => {
            this.setState({errormessage: error.message});
            console.log(this.state.errormessage)
            this.setState({iserror: true});
        })

    }

    renderErrorMessage(){
        if(this.state.iserror===true){
            if(this.state.errormessage === "Request failed with status code 401"){
                return(
                    <div>
                            <h1 className = "login-fail">Log in failed</h1>
                            <h2 className = "login-fail">Login info is not correct</h2>
                    </div>

                )
            }
        }        
    }

    render(){

        return(
        <div>
        <Form onSubmit = {e => this.submit(e)}>
            <img className="img-logo" alt="timer" src={require('../img/')} />
            
            <div className="loginfoorm">
            <h1 className="header-text">Login Form</h1>
            <h3 className="login-text-tag">If you have already registered, please login with the registered email and password.</h3>
            <FormGroup row>
            <Label className="header-text" for="exampleEmail" sm={2}>Email</Label>
            <Col sm={10}>
                <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" onChange = {e => this.change(e)} value = {this.state.email}/>  
            </Col>
            </FormGroup>
            <FormGroup row>
            <Label className="header-text" for="examplePassword" sm={2}>Password</Label>
            <Col sm={10}>
                <Input type="password" name="password" id="examplePassword" placeholder="password placeholder" onChange = {e => this.change(e)} value = {this.state.password}/>
            </Col>
            </FormGroup>
            <Button color="info" size="lg" block>Login</Button>
            </div>

            
            {this.renderErrorMessage()}
            
            
         </Form>
          </div>   
        )
    }
}


const mapDispatchToProps = (dispatch) => {
    return {
        signIn: () => dispatch(setLoginTrue())
    }
};



export default connect(null, mapDispatchToProps)(Login);