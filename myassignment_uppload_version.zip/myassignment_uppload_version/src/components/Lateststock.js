import React, { Component } from 'react';
import axios from 'axios';
import { Jumbotron, Table } from 'reactstrap';

const localhost = 'http://131.181.190.87:3000';

export default class Top extends Component{

    constructor(props){
        super(props)
        this.state = {
            symbol: "",
            stock_name: "",
            stock_industry:"",
            stock_open: "",
            stock_high: "",
            stock_low: "",
            stock_close:"",
            stock_volumes: ""
        }

        this.change = this.change.bind(this);
        this.getstocksymbol = this.getstocksymbol.bind(this);
    }


    change(e){
        this.setState({
            symbol: e.target.value
        })
    }

    getstocksymbol(e){
        e.preventDefault();
        const input = this.state.symbol
        console.log(input)
        axios.get(`${localhost}/stocks/${input}`)
        .then(res => {
            this.setState({stock_name: res.data.name})
            this.setState({stock_industry: res.data.industry})
            this.setState({stock_open: res.data.open})
            this.setState({stock_high: res.data.high})
            this.setState({stock_low: res.data.low})
            this.setState({stock_close: res.data.close})
            this.setState({stock_volumes: res.data.volumes})
        })
        .catch(error => {
            console.log(error)
        });
    }

    render(){
        return(
            <div>
                    <div className="quote-title">
                    <Jumbotron>
                        <h1 className="display-3">Get the latest price information by  stock symbol</h1>
                        <hr className="my-2" />
                        <p>If you do not know company's symbols, you can go to stock lists to find corresponding symbols.</p>
                        <p className="lead">
                        </p>
                    </Jumbotron>
                    

                
                <h1 className="App">Type company's symbol</h1>
                <form className="stock-table1" onSubmit = {this.getstocksymbol}>
                    <input type="text" name="symbol" onChange = {e => this.change(e)} value = {this.state.symbol}/>
                    <button className="input">Search</button>
                </form>
                


                <Table>
                    <thead>
                        <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Industory</th>
                        <th>Open</th>
                        <th>High</th>
                        <th>Low</th>
                        <th>Close</th>
                        <th>Volumes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <th scope="row"></th>
                        <td>{this.state.stock_name}</td>
                        <td>{this.state.stock_industry}</td>
                        <td>{this.state.stock_open}</td>
                        <td>{this.state.stock_high}</td>
                        <td>{this.state.stock_low}</td>
                        <td>{this.state.stock_close}</td>
                        <td>{this.state.stock_volumes}</td>
                        </tr>

                    </tbody>
                </Table>
                </div>
            </div>

        )
    }
}
