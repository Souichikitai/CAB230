import React, {Component} from 'react';
import { Button, Form, FormGroup, Label, Input, Col } from 'reactstrap';
import '../App.css';

import axios from 'axios';

const localhost = 'http://131.181.190.87:3000'

export default class Login extends Component{
    constructor(props){
        super(props);
        this.state = {
            content: " ",
            email:"",
            password: "",
            errormessage:"",
            iserror: false,
            isregisterd: false
        }

        this.change = this.change.bind(this);
        this.submit = this.submit.bind(this);
    }

    change(e){
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    submit(e){
        e.preventDefault();
        axios.post(`${localhost}/user/register`, {
            email: this.state.email,
            password: this.state.password,
            // isregisterd: true
        }).then(res => localStorage.setItem('jwt', res.data.token)
        ).then(this.setState({iserror: false}),this.setState({isregisterd: true})).catch(error => {
            this.setState({errormessage: error.message});
            this.setState({iserror: true});
            console.log(this.state.iserror);
        });
    }

    renderErrorMessage(){
        if(this.state.iserror===true){
            if(this.state.errormessage === "Request failed with status code 400"){
                return(
                    <div>
                        <h1 className = "login-fail">Registoration failed</h1>
                        <h2 className = "login-fail">Request body incomplete - email and password needed</h2>
                    </div>

                )
            }
            if(this.state.errormessage === "Request failed with status code 409"){
                return(
                    <div>
                        <h1 className = "login-fail">Registoration failed</h1>
                        <h2 className = "login-fail">User already exists</h2>
                    </div>

                )
            }
            
        }else if(this.state.isregisterd === true){
            return(
                <div>
                <h1 className = "login-fail">Registoration Success</h1>
            </div>
            )
        }        
    }

    render(){
        return(
            <div>
             <Form onSubmit = {e => this.submit(e)}>
                <img className="img-logo" alt="timer" src={require('../img/LogoMakr_7K6Ttl.png')} />
                
                <div className="register-foorm">
                <h1 className="header-text">Register Form</h1>
                <h3 className="login-text-tag">Signup with setting your email and password!</h3>
                <FormGroup row>
                <Label className="header-text" for="exampleEmail" sm={2}>Email</Label>
                <Col sm={10}>
                    <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" onChange = {e => this.change(e)} value = {this.state.email}/>
                </Col>
                </FormGroup>
                <FormGroup row>
                <Label className="header-text" for="examplePassword" sm={2}>Password</Label>
                <Col sm={10}>
                    <Input type="password" name="password" id="examplePassword" placeholder="password placeholder" onChange = {e => this.change(e)} value = {this.state.password}/>
                </Col>
                </FormGroup>

                <Button color="success" size="lg" block>Register</Button>
                </div>
             </Form>
                 {this.renderErrorMessage()}
            </div>
        )
    }
}