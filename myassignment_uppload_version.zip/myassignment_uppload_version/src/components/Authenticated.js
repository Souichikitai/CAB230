import React, {Component} from 'react';

import {withRouter} from 'react-router-dom';
class Authenticated extends Component{

    constructor(props){
        super(props)
        
        this.state = {
            user: undefined,
            isloading: true
        }
    }

    getJWT = () => {
        return localStorage.getItem('jwt')
    }

    componentDidMount(){
        const jwt = this.getJWT();
        
        if(!jwt){

            this.props.history.push('/');
        }

        this.setState({isloading: false})

        this.setState({login: true})

        const username = localStorage.getItem('jwt');

        this.setState({user: username});
    }

    render(){
        if(this.state.isloading === true){
        
            return <div><h1>Loading...</h1></div>
        }
        else{
        return(
            <div>
                {this.props.children}
            </div>
        )
        }
    }

}


export default (withRouter(Authenticated));
