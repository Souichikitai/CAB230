import React from 'react';
import {
  BrowserRouter as Router,
  Route, Switch,Link
} from 'react-router-dom'
import {    Navbar,
  NavbarBrand,
  Nav,
  NavLink,
  UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem
} from 'reactstrap';

import './App.css';
import Welcome from './components/Welcome';
import Login from './components/Login';
import Register from './components/Register';
import Top from './components/Top';
import Auth from './components/Authenticated';
import {useSelector} from 'react-redux';
import Stocklists from './components/Stocklists';
import Lateststock from './components/Lateststock';
import Industrylists from './components/Industrylists';


function App() {

  const movetomenu = () => {
    window.location.reload(false);
    localStorage.removeItem('jwt');
  }

  

  const userlogin = (
    
    <div>
      <Link to={'/login'} style={{color: 'black'}}>Login</Link>
    </div>
  );

  const userlogout = (
    <div>
      <Link to={'/'} style={{color: 'black'}} onClick = {movetomenu}>Logout</Link>
    </div>
  );

  const userout = (
    <div>
      <NavLink></NavLink>
    </div>
  );


  const userin = (
    <div>
      <Link to={'/register'} style={{color: 'black'}}>Register</Link>
    </div>
  );

  const userinstock = (
    <div>
        <Nav className="mr-auto" navbar>
            <UncontrolledDropdown nav inNavbar>
              <DropdownToggle nav caret >
                Stocks
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem>
                <Link to={'/top'} style={{color: 'black'}}>Stock Top</Link>
                </DropdownItem>
                <DropdownItem>
                <Link to={'/stocklists'} style={{color: 'black'}}>Stocks Lists</Link>
                </DropdownItem>
                {/* <DropdownItem divider /> */}
                <DropdownItem>
                <Link to={'/lateststock'} style={{color: 'black'}}>Latest Stock</Link>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
  </Nav>
    </div>
  );



  let userconnection = useSelector(state => state.isLogged);
  console.log(userconnection);

  const isloggedin = userconnection? userlogout : userlogin;
  const isloggedForReg = userconnection? userout : userin;
  const isuserisllogedin = userconnection?userinstock: userout; 

  return (
<div>
    <style>
    {
      `.bar-tag{
          width: 100%;
          height:70px;

      }`
    }
  </style>
  <Router>
    
  <Navbar className="bar-tag" color="info" light expand="md">

  <NavbarBrand href="/">Stocks Library</NavbarBrand>
  {isuserisllogedin}
  <Nav className="mr-auto" navbar>
  </Nav>
  <NavLink >{isloggedForReg}</NavLink>
  <NavLink >{isloggedin}</NavLink>
  </Navbar>

  
<Switch>
        <Route exact path = '/' component={Welcome} /> 
        <Route path = '/login' component={Login} />
        <Route path = '/register' component={Register} />        
        <Auth >
        <Route path = '/stocklists'  component={Stocklists}/>
        <Route path = '/lateststock' component={Lateststock} />
        <Route path = '/top' component={Top} />
        <Route path = '/industrylists' component={Industrylists}/>
        </Auth>
        </Switch>

    </Router>

    </div>

  );
  }



export default App;
