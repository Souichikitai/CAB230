export const setLoginTrue = () => {
    return{
        type: 'LOGGED_IN'
    }
}

export const setAuthedError = () => {
    return{
        type: "Unauthed"
    }
}