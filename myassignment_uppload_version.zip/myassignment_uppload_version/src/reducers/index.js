import LoggedReducer from './islogged';
import AuthReducer from './isauthed';
import {combineReducers} from 'redux';

const allReducers = combineReducers({
    isLogged: LoggedReducer,
    isAuthed: AuthReducer
});

export default allReducers;
